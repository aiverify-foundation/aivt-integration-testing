"""
Main package for Accumulated Local Effect plugin.
"""
